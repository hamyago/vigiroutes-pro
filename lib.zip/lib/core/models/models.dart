// ── ProviderAssistant ─────────────────────────────────────────────────────────
// Intervenant rattaché au prestataire principal (membre de son garage).
// N'est PAS un compte : pas d'auth, pas de commande reçue. Sert uniquement à
// désigner qui intervient physiquement sur une commande acceptée.

class ProviderAssistant {
  final int id;
  final String name;
  final String? phone;
  final String? photoUrl;
  final bool isActive;

  const ProviderAssistant({
    required this.id,
    required this.name,
    this.phone,
    this.photoUrl,
    this.isActive = true,
  });

  static int _toInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse('$v') ?? 0;
  }

  static bool _toBool(dynamic v) =>
      v == true || v == 1 || v == '1' || v == 'true';

  factory ProviderAssistant.fromJson(Map<String, dynamic> json) => ProviderAssistant(
        id:       _toInt(json['id']),
        name:     (json['name'] ?? '').toString(),
        phone:    json['phone']?.toString(),
        photoUrl: json['photo_url']?.toString(),
        isActive: json['is_active'] == null ? true : _toBool(json['is_active']),
      );

  // Conservé compact pour survivre aux fusions copyWithWs.
  Map<String, dynamic> toJson() => {
        'id':        id,
        'name':      name,
        'phone':     phone,
        'photo_url': photoUrl,
        'is_active': isActive,
      };
}

// ── UserModel ─────────────────────────────────────────────────────────────────

class UserModel {
  final String id;
  final String name;
  final String phone;
  final String? email;
  final String? photoUrl;
  final String? fcmToken;
  final bool isActive;
  final String subscriptionPlan;
  final DateTime? subscriptionExpiresAt;
  final int totalInterventions;

  const UserModel({
    required this.id,
    required this.name,
    required this.phone,
    this.email,
    this.photoUrl,
    this.fcmToken,
    required this.isActive,
    required this.subscriptionPlan,
    this.subscriptionExpiresAt,
    required this.totalInterventions,
  });

  bool get hasSubscription =>
      subscriptionPlan != 'none' &&
      (subscriptionExpiresAt == null || subscriptionExpiresAt!.isAfter(DateTime.now()));

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id:                    json['id'] as String,
        name:                  json['name'] as String,
        phone:                 json['phone'] as String,
        email:                 json['email'] as String?,
        photoUrl:              json['photo_url'] as String?,
        fcmToken:              json['fcm_token'] as String?,
        isActive:              json['is_active'] as bool? ?? true,
        subscriptionPlan:      json['subscription_plan'] as String? ?? 'none',
        subscriptionExpiresAt: json['subscription_expires_at'] != null
            ? DateTime.parse(json['subscription_expires_at'] as String)
            : null,
        totalInterventions: json['total_interventions'] as int? ?? 0,
      );
}

// ── ProviderModel ─────────────────────────────────────────────────────────────

class ProviderModel {
  final String id;
  final String name;
  final String phone;
  final String? photoUrl;
  final String? fcmToken;
  final double latitude;
  final double longitude;
  final bool isAvailable;
  final bool isActive;
  final bool isVerified;
  final String? idCardUrl;
  final String? proLicenseUrl;
  final List<String> serviceTypes;
  final double rating;
  final int ratingCount;
  final double totalEarnings;
  final int totalInterventions;
  double? distanceKm;

  ProviderModel({
    required this.id,
    required this.name,
    required this.phone,
    this.photoUrl,
    this.fcmToken,
    required this.latitude,
    required this.longitude,
    required this.isAvailable,
    required this.isActive,
    required this.isVerified,
    this.idCardUrl,
    this.proLicenseUrl,
    required this.serviceTypes,
    required this.rating,
    required this.ratingCount,
    required this.totalEarnings,
    required this.totalInterventions,
    this.distanceKm,
  });

  factory ProviderModel.fromJson(Map<String, dynamic> json) => ProviderModel(
        id:                 json['id'] as String? ?? '',
        name:               json['name'] as String? ?? 'Prestataire',
        phone:              json['phone'] as String? ?? '',
        photoUrl:           json['photo_url'] as String?,
        fcmToken:           json['fcm_token'] as String?,
        latitude:           _numToDouble(json['latitude']),
        longitude:          _numToDouble(json['longitude']),
        isAvailable:        json['is_available'] as bool? ?? true,
        isActive:           json['is_active'] as bool? ?? true,
        isVerified:         json['is_verified'] as bool? ?? false,
        idCardUrl:          json['id_card_url'] as String?,
        proLicenseUrl:      json['pro_license_url'] as String?,
        serviceTypes:       (json['service_types'] as List?)
                                ?.map((e) => e as String).toList() ?? [],
        rating:             _numToDouble(json['rating']),
        ratingCount:        _numToInt(json['rating_count']),
        totalEarnings:      _numToDouble(json['total_earnings']),
        totalInterventions: _numToInt(json['total_interventions']),
        distanceKm:         _numToDoubleN(json['distance_km']),
      );
}

// ── InterventionModel ─────────────────────────────────────────────────────────

class InterventionModel {
  final String id;
  final String userId;
  final String? userName;
  final String? providerId;
  final String serviceTypeId;
  final String serviceTypeName;
  final String status;
  final double userLatitude;
  final double userLongitude;
  final String? userAddress;
  final double? providerLatitude;
  final double? providerLongitude;
  final double basePrice;
  final double distanceKm;
  final double kmCost;
  final double subtotal;
  final double commission;
  final double totalPrice;
  final bool subscriptionDiscountApplied;
  final String paymentMethod;
  final String paymentStatus;
  final String? dispatchedProviderId;
  final DateTime? dispatchExpiresAt;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final ProviderModel? provider;
  final ProviderAssistant? assignedAssistant;

  // ── Champs Contrôle Technique (CT) ─────────────────────────────────────────
  final bool isCTTransport;
  final String? ctBookingId;
  final String? ctCenterName;
  final String? ctCenterAddress;
  final double? ctCenterLatitude;
  final double? ctCenterLongitude;
  final String ctPhase;

  const InterventionModel({
    required this.id,
    required this.userId,
    this.userName,
    this.providerId,
    required this.serviceTypeId,
    required this.serviceTypeName,
    required this.status,
    required this.userLatitude,
    required this.userLongitude,
    this.userAddress,
    this.providerLatitude,
    this.providerLongitude,
    required this.basePrice,
    required this.distanceKm,
    required this.kmCost,
    required this.subtotal,
    required this.commission,
    required this.totalPrice,
    required this.subscriptionDiscountApplied,
    required this.paymentMethod,
    required this.paymentStatus,
    this.dispatchedProviderId,
    this.dispatchExpiresAt,
    required this.createdAt,
    this.acceptedAt,
    this.startedAt,
    this.completedAt,
    this.provider,
    this.assignedAssistant,
    this.isCTTransport = false,
    this.ctBookingId,
    this.ctCenterName,
    this.ctCenterAddress,
    this.ctCenterLatitude,
    this.ctCenterLongitude,
    this.ctPhase = 'pickup',
  });

  bool get isPending    => status == 'pending' || status == 'dispatching';
  bool get isAccepted   => status == 'accepted';
  bool get isInProgress => status == 'in_progress';
  bool get isCompleted  => status == 'completed';
  bool get isCancelled  => status == 'cancelled';
  bool get isActive     => isPending || isAccepted || isInProgress;

  /// Vrai quand le prestataire a confirmé le ramassage et navigue vers le centre
  bool get isInDeliveryPhase => isCTTransport && ctPhase == 'delivery';

  // ── Alias sémantiques pour l'alerte vocale Option C ──────────────────────
  // Évite de modifier provider_controller ou alert_service quand les noms de
  // champs changent : un seul endroit à adapter.

  /// Nom du client (utilisateur qui a passé la commande).
  String? get clientName => userName;

  /// Adresse de prise en charge (là où le client est en panne).
  String? get address => userAddress;

  /// Montant estimé pour la voix — affiche le total sans commission.
  String? get estimatedPrice => totalPrice > 0
      ? totalPrice.toStringAsFixed(0)
      : null;

  factory InterventionModel.fromJson(Map<String, dynamic> json) {
    final ctData = json['ct'] as Map<String, dynamic>?;
    return InterventionModel(
        id:                          json['id'] as String,
        userId:                      json['user_id'] as String,
        userName:                    json['user_name'] as String? ??
            (json['user'] as Map<String, dynamic>?)?['name'] as String?,
        providerId:                  json['provider_id'] as String?,
        serviceTypeId:               json['service_type_id'] as String,
        serviceTypeName:             json['service_type_name'] as String,
        status:                      json['status'] as String,
        userLatitude:                (json['user_latitude'] as num).toDouble(),
        userLongitude:               (json['user_longitude'] as num).toDouble(),
        userAddress:                 json['user_address'] as String?,
        providerLatitude:            (json['provider_latitude'] as num?)?.toDouble(),
        providerLongitude:           (json['provider_longitude'] as num?)?.toDouble(),
        basePrice:                   (json['base_price'] as num).toDouble(),
        distanceKm:                  (json['distance_km'] as num).toDouble(),
        kmCost:                      (json['km_cost'] as num).toDouble(),
        subtotal:                    (json['subtotal'] as num).toDouble(),
        commission:                  (json['commission'] as num).toDouble(),
        totalPrice:                  (json['total_price'] as num).toDouble(),
        subscriptionDiscountApplied: json['subscription_discount_applied'] as bool? ?? false,
        paymentMethod:               json['payment_method'] as String,
        paymentStatus:               json['payment_status'] as String? ?? 'pending',
        dispatchedProviderId:        json['dispatched_provider_id'] as String?,
        dispatchExpiresAt:           json['dispatch_expires_at'] != null
            ? DateTime.parse(json['dispatch_expires_at'] as String)
            : null,
        createdAt:    DateTime.parse(json['created_at'] as String),
        acceptedAt:   json['accepted_at'] != null  ? DateTime.parse(json['accepted_at'] as String)  : null,
        startedAt:    json['started_at'] != null   ? DateTime.parse(json['started_at'] as String)   : null,
        completedAt:  json['completed_at'] != null ? DateTime.parse(json['completed_at'] as String) : null,
        provider:     json['provider'] != null
            ? ProviderModel.fromJson(json['provider'] as Map<String, dynamic>)
            : null,
        assignedAssistant: json['assigned_assistant'] != null
            ? ProviderAssistant.fromJson(json['assigned_assistant'] as Map<String, dynamic>)
            : null,
        isCTTransport:      json['is_ct_transport'] as bool? ?? false,
        ctBookingId:        ctData?['booking_id'] as String? ?? json['ct_booking_id'] as String?,
        ctCenterName:       ctData?['center_name'] as String? ?? json['ct_center_name'] as String?,
        ctCenterAddress:    ctData?['center_address'] as String? ?? json['ct_center_address'] as String?,
        ctCenterLatitude:   _numToDoubleN(ctData?['center_latitude'] ?? json['ct_center_latitude']),
        ctCenterLongitude:  _numToDoubleN(ctData?['center_longitude'] ?? json['ct_center_longitude']),
        ctPhase:            json['ct_phase'] as String? ?? 'pickup',
    );
  }

  /// Mise à jour partielle depuis un événement WebSocket
  InterventionModel copyWithWs(Map<String, dynamic> data) => InterventionModel(
        id:                          id,
        userId:                      userId,
        userName:                    userName,
        providerId:                  data['provider_id'] as String? ?? providerId,
        serviceTypeId:               serviceTypeId,
        serviceTypeName:             serviceTypeName,
        status:                      data['status'] as String? ?? status,
        userLatitude:                userLatitude,
        userLongitude:               userLongitude,
        userAddress:                 userAddress,
        providerLatitude:            (data['provider_latitude'] as num?)?.toDouble() ?? providerLatitude,
        providerLongitude:           (data['provider_longitude'] as num?)?.toDouble() ?? providerLongitude,
        basePrice:                   basePrice,
        distanceKm:                  distanceKm,
        kmCost:                      kmCost,
        subtotal:                    subtotal,
        commission:                  commission,
        totalPrice:                  totalPrice,
        subscriptionDiscountApplied: subscriptionDiscountApplied,
        paymentMethod:               paymentMethod,
        paymentStatus:               paymentStatus,
        dispatchedProviderId:        data['dispatched_provider_id'] as String? ?? dispatchedProviderId,
        dispatchExpiresAt:           data['dispatch_expires_at'] != null
            ? DateTime.parse(data['dispatch_expires_at'] as String)
            : dispatchExpiresAt,
        createdAt:   createdAt,
        acceptedAt:  acceptedAt,
        startedAt:   startedAt,
        completedAt: completedAt,
        provider:    provider,
        assignedAssistant: data['assigned_assistant'] != null
            ? ProviderAssistant.fromJson(data['assigned_assistant'] as Map<String, dynamic>)
            : assignedAssistant,
        isCTTransport:     isCTTransport,
        ctBookingId:       ctBookingId,
        ctCenterName:      ctCenterName,
        ctCenterAddress:   ctCenterAddress,
        ctCenterLatitude:  ctCenterLatitude,
        ctCenterLongitude: ctCenterLongitude,
        ctPhase:           data['ct_phase'] as String? ?? ctPhase,
      );

  /// Passe à la phase livraison (après ramassage confirmé)
  InterventionModel toDeliveryPhase() => copyWithWs({'ct_phase': 'delivery'});
}

// ── ReviewModel ──────────────────────────────────────────────────────────────

class ReviewModel {
  final String id;
  final String interventionId;
  final double rating;
  final String? comment;
  final DateTime createdAt;

  const ReviewModel({
    required this.id,
    required this.interventionId,
    required this.rating,
    this.comment,
    required this.createdAt,
  });

  factory ReviewModel.fromJson(Map<String, dynamic> json) => ReviewModel(
        id:             json['id'] as String,
        interventionId: json['intervention_id'] as String,
        rating:         json['rating'] is num
            ? (json['rating'] as num).toDouble()
            : double.tryParse(json['rating'].toString()) ?? 0,
        comment:        json['comment'] as String?,
        createdAt:      DateTime.parse(json['created_at'] as String),
      );
}

// ── Pièces automobiles (magasins) ─────────────────────────────────────────────

class StoreProductModel {
  final String id;
  final String name;
  final double unitPrice;
  final bool isAvailable;

  const StoreProductModel({
    required this.id,
    required this.name,
    required this.unitPrice,
    required this.isAvailable,
  });

  factory StoreProductModel.fromJson(Map<String, dynamic> json) => StoreProductModel(
        id:          json['id'] as String,
        name:        json['name'] as String,
        unitPrice:   json['unit_price'] is num
            ? (json['unit_price'] as num).toDouble()
            : double.tryParse(json['unit_price'].toString()) ?? 0,
        isAvailable: json['is_available'] as bool? ?? true,
      );
}

class StoreModel {
  final String id;
  final String name;
  final String? phone;
  final String? address;
  final double? latitude;
  final double? longitude;
  final double? distanceKm;
  final double rating;
  final int ratingCount;
  final List<StoreProductModel> products;

  const StoreModel({
    required this.id,
    required this.name,
    this.phone,
    this.address,
    this.latitude,
    this.longitude,
    this.distanceKm,
    this.rating = 0,
    this.ratingCount = 0,
    this.products = const [],
  });

  static double? _numOrNull(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  static double _num(dynamic v, [double fallback = 0]) => _numOrNull(v) ?? fallback;

  factory StoreModel.fromJson(Map<String, dynamic> json) => StoreModel(
        id:         json['id'] as String,
        name:       json['name'] as String,
        phone:      json['phone'] as String?,
        address:    json['address'] as String?,
        latitude:   _numOrNull(json['latitude']),
        longitude:  _numOrNull(json['longitude']),
        distanceKm: _numOrNull(json['distance_km']),
        rating:     _num(json['rating']),
        ratingCount:(json['rating_count'] as num?)?.toInt() ?? int.tryParse(json['rating_count']?.toString() ?? '') ?? 0,
        products:   (json['products'] as List<dynamic>? ?? [])
            .map((p) => StoreProductModel.fromJson(p as Map<String, dynamic>))
            .toList(),
      );
}

class PartOrderItemModel {
  final String productName;
  final double unitPrice;
  final int quantity;
  final double subtotal;

  const PartOrderItemModel({
    required this.productName,
    required this.unitPrice,
    required this.quantity,
    required this.subtotal,
  });

  factory PartOrderItemModel.fromJson(Map<String, dynamic> json) => PartOrderItemModel(
        productName: json['product_name'] as String,
        unitPrice:   (json['unit_price'] as num?)?.toDouble() ?? 0,
        quantity:    (json['quantity'] as num?)?.toInt() ?? 0,
        subtotal:    (json['subtotal'] as num?)?.toDouble() ?? 0,
      );
}

class PartOrderModel {
  final String id;
  final String status;
  final double totalAmount;
  final DateTime createdAt;
  final List<PartOrderItemModel> items;
  final Map<String, dynamic>? store;

  const PartOrderModel({
    required this.id,
    required this.status,
    required this.totalAmount,
    required this.createdAt,
    this.items = const [],
    this.store,
  });

  factory PartOrderModel.fromJson(Map<String, dynamic> json) => PartOrderModel(
        id:          json['id'] as String,
        status:      json['status'] as String? ?? 'pending',
        totalAmount: (json['total_amount'] as num?)?.toDouble() ?? 0,
        createdAt:   DateTime.parse(json['created_at'] as String),
        items: (json['items'] as List<dynamic>? ?? [])
            .map((i) => PartOrderItemModel.fromJson(i as Map<String, dynamic>))
            .toList(),
        store: json['store'] as Map<String, dynamic>?,
      );
}

// ── Helpers de parsing tolérants ─────────────────────────────────────────────
double _numToDouble(dynamic v, [double fallback = 0]) {
  if (v == null) return fallback;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString()) ?? fallback;
}

double? _numToDoubleN(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString());
}

int _numToInt(dynamic v, [int fallback = 0]) {
  if (v == null) return fallback;
  if (v is num) return v.toInt();
  return int.tryParse(v.toString()) ?? fallback;
}
