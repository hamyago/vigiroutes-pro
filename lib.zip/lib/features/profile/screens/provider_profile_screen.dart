import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/models/models.dart';
import '../../../core/services/api_service.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../../core/theme/theme_controller.dart';
import '../../../shared/widgets/provider_bottom_nav.dart';
import '../../legal/screens/privacy_policy_screen.dart';


class ProviderProfileScreen extends StatelessWidget {
  const ProviderProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth     = context.watch<AuthController>();
    final provider = auth.provider;
    final uid      = auth.provider?.id ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Mon profil')),
      bottomNavigationBar: const ProviderBottomNav(),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _PhotoAvatar(uid: uid, photoUrl: provider?.photoUrl),
          const SizedBox(height: 24),
          _InfoCard(provider: provider),
          const SizedBox(height: 16),
          _KycCard(provider: provider, uid: uid),
          const SizedBox(height: 16),
          _StatsCard(provider: provider),
          const SizedBox(height: 16),
          _SubscriptionCard(onTap: () => context.push('/provider/subscription')),
          const SizedBox(height: 16),
          _RatesCard(onTap: () => context.push('/provider/rates')),
          const SizedBox(height: 16),
          _MenuTile(
            icon: Icons.person_outline,
            title: 'Informations prestataire',
            onTap: () => context.push('/provider/info'),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.groups_outlined,
            title: 'Mon équipe',
            onTap: () => context.push('/provider/team'),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.privacy_tip_outlined,
            title: 'Politique de confidentialité',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()),
            ),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.description_outlined,
            title: 'Conditions d\'utilisation',
            onTap: () async {
              final uri = Uri.parse('https://vigiroutes.com/cgu');
              if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Impossible d\'ouvrir la page.')),
                  );
                }
              }
            },
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.star_outline,
            title: 'Mes avis',
            onTap: () => context.push('/provider/reviews'),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.build_circle_outlined,
            title: 'Pièces auto',
            onTap: () => context.push('/provider/parts'),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.receipt_long_outlined,
            title: 'Mes commandes de pièces',
            onTap: () => context.push('/provider/parts/orders'),
          ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.receipt_long_outlined,
            title: 'Historique des souscriptions',
            onTap: () => context.push('/provider/subscription/history'),
          ),
          const SizedBox(height: 12),
          const _DarkModeTile(),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: () async => await auth.signOut(),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.error,
                side: const BorderSide(color: AppColors.error),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Se déconnecter'),
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _MenuTile(
      {required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(14),
      child: ListTile(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

class _DarkModeTile extends StatelessWidget {
  const _DarkModeTile();

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeController>();
    final isDark = theme.isDark ||
        (theme.mode == ThemeMode.system &&
            MediaQuery.of(context).platformBrightness == Brightness.dark);
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(14),
      child: SwitchListTile(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        secondary: Icon(isDark ? Icons.dark_mode : Icons.light_mode,
            color: Theme.of(context).colorScheme.primary),
        title: const Text('Mode sombre',
            style: TextStyle(fontWeight: FontWeight.w600)),
        value: isDark,
        onChanged: (v) => theme.toggleDark(v),
      ),
    );
  }
}

class _RatesCard extends StatelessWidget {
  final VoidCallback onTap;
  const _RatesCard({required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.primary.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text('💰', style: TextStyle(fontSize: 24)),
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Mes tarifs',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            color: AppColors.textPrimary)),
                    Text('Personnaliser mes prix par service',
                        style: TextStyle(
                            color: AppColors.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.textMuted),
            ],
          ),
        ),
      );
}

class _PhotoAvatar extends StatefulWidget {
  final String uid;
  final String? photoUrl;
  const _PhotoAvatar({required this.uid, this.photoUrl});

  @override
  State<_PhotoAvatar> createState() => _PhotoAvatarState();
}

class _PhotoAvatarState extends State<_PhotoAvatar> {
  bool _loading  = false;
  int  _cacheKey = 0;

  Future<void> _pickPhoto() async {
    if (kIsWeb) return;
    final picker = ImagePicker();
    final file   = await picker.pickImage(
        source: ImageSource.gallery, imageQuality: 80, maxWidth: 800);
    if (file == null) return;
    setState(() => _loading = true);
    try {
      // Lire le fichier et convertir en base64
      final bytes = await File(file.path).readAsBytes();
      final base64Image = base64Encode(bytes);
      final ext = file.path.split('.').last.toLowerCase();

      await ApiService.instance.updateProvider({
        'photo_base64': 'data:image/$ext;base64,$base64Image',
      });

      // Rafraîchir le profil
      if (mounted) {
        final auth = context.read<AuthController>();
        await auth.refreshProvider();
        setState(() => _cacheKey = DateTime.now().millisecondsSinceEpoch);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Photo mise à jour ✅'),
            backgroundColor: AppColors.success));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Erreur : $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Center(
        child: GestureDetector(
          onTap: _pickPhoto,
          child: Stack(children: [
            CircleAvatar(
              radius: 52,
              backgroundColor: AppColors.primaryLight,
              backgroundImage: widget.photoUrl != null
                  ? NetworkImage('${widget.photoUrl}?v=$_cacheKey')
                  : null,
              child: widget.photoUrl == null
                  ? const Text('🔧', style: TextStyle(fontSize: 40))
                  : null,
            ),
            if (_loading)
              const Positioned.fill(
                child: CircleAvatar(
                    radius: 52,
                    backgroundColor: Colors.black26,
                    child: CircularProgressIndicator(color: Colors.white)),
              ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                decoration: const BoxDecoration(
                    color: AppColors.primary, shape: BoxShape.circle),
                padding: const EdgeInsets.all(6),
                child: const Icon(Icons.camera_alt,
                    color: Colors.white, size: 16),
              ),
            ),
          ]),
        ),
      );
}

class _InfoCard extends StatelessWidget {
  final ProviderModel? provider;
  const _InfoCard({this.provider});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Informations',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 12),
          _Row(icon: Icons.person_outline,
              label: 'Nom', value: provider?.name ?? '—'),
          _Row(icon: Icons.phone_outlined,
              label: 'Téléphone', value: provider?.phone ?? '—'),
          _Row(icon: Icons.star_outline,
              label: 'Note',
              value: '${(provider?.rating ?? 0.0).toStringAsFixed(1)} ★ (${provider?.ratingCount ?? 0} avis)'),
          _Row(
              icon: provider?.isAvailable == true
                  ? Icons.check_circle_outline
                  : Icons.cancel_outlined,
              label: 'Statut',
              value: provider?.isAvailable == true ? 'Disponible' : 'Indisponible',
              valueColor: provider?.isAvailable == true
                  ? AppColors.success : AppColors.error),
        ]),
      );
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   value;
  final Color?   valueColor;
  const _Row({required this.icon, required this.label,
      required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Icon(icon, size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Text('$label : ',
              style: const TextStyle(color: AppColors.textSecondary)),
          Expanded(
              child: Text(value,
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: valueColor ?? AppColors.textPrimary))),
        ]),
      );
}

class _KycCard extends StatefulWidget {
  final ProviderModel? provider;
  final String uid;
  const _KycCard({this.provider, required this.uid});

  @override
  State<_KycCard> createState() => _KycCardState();
}

class _KycCardState extends State<_KycCard> {
  bool _loading = false;

  // Statut local pour mise à jour immédiate de l'UI
  bool _idCardSubmitted  = false;
  bool _licenseSubmitted = false;

  @override
  void initState() {
    super.initState();
    // Statut réel : un document est « soumis » s'il a une URL enregistrée.
    _idCardSubmitted  = (widget.provider?.idCardUrl?.isNotEmpty ?? false);
    _licenseSubmitted = (widget.provider?.proLicenseUrl?.isNotEmpty ?? false)
        || (widget.provider?.isVerified ?? false);
  }

  Future<void> _uploadDoc(String field, String label) async {
    if (kIsWeb) return;
    final picker = ImagePicker();
    final file   = await picker.pickImage(
        source: ImageSource.gallery, imageQuality: 85, maxWidth: 1200);
    if (file == null) return;
    setState(() => _loading = true);
    try {
      final bytes       = await File(file.path).readAsBytes();
      final base64Image = base64Encode(bytes);
      final ext         = file.path.split('.').last.toLowerCase();

      await ApiService.instance.updateProvider({
        field: 'data:image/$ext;base64,$base64Image',
      });

      setState(() {
        if (field == 'id_card_url')     _idCardSubmitted  = true;
        if (field == 'pro_license_url') _licenseSubmitted = true;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('$label envoyé ✅'),
            backgroundColor: AppColors.success));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Erreur : $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Documents KYC',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 4),
          const Text('Soumettez vos documents pour être vérifié par Oyop MT.',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 16),
          _DocRow(
            label: "Pièce d'identité",
            status: _idCardSubmitted ? 'Soumis ✅' : 'Non soumis',
            statusColor: _idCardSubmitted ? AppColors.success : AppColors.warning,
            onUpload: _loading ? null
                : () => _uploadDoc('id_card_url', "Pièce d'identité"),
          ),
          const SizedBox(height: 8),
          _DocRow(
            label: 'Licence professionnelle',
            status: widget.provider?.isVerified == true
                ? 'Vérifié ✅'
                : _licenseSubmitted ? 'Soumis ✅' : 'Non soumis',
            statusColor: widget.provider?.isVerified == true
                ? AppColors.success
                : _licenseSubmitted ? AppColors.success : AppColors.warning,
            onUpload: _loading ? null
                : () => _uploadDoc('pro_license_url', 'Licence professionnelle'),
          ),
        ]),
      );
}

class _DocRow extends StatelessWidget {
  final String    label;
  final String    status;
  final Color     statusColor;
  final VoidCallback? onUpload;
  const _DocRow({required this.label, required this.status,
      required this.statusColor, this.onUpload});

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(status, style: TextStyle(color: statusColor, fontSize: 12)),
            ])),
        TextButton.icon(
          onPressed: onUpload,
          icon: const Icon(Icons.upload_file, size: 16),
          label: const Text('Envoyer'),
        ),
      ]);
}

class _StatsCard extends StatelessWidget {
  final ProviderModel? provider;
  const _StatsCard({this.provider});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Statistiques',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 12),
          Row(children: [
            _StatBox(label: 'Interventions',
                value: '${provider?.totalInterventions ?? 0}'),
            const SizedBox(width: 12),
            _StatBox(label: 'Gains totaux',
                value: '${(provider?.totalEarnings ?? 0).toStringAsFixed(0)} F'),
          ]),
        ]),
      );
}

class _StatBox extends StatelessWidget {
  final String label;
  final String value;
  const _StatBox({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(children: [
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 20,
                    color: AppColors.primary)),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12)),
          ]),
        ),
      );
}

class _SubscriptionCard extends StatelessWidget {
  final VoidCallback onTap;
  const _SubscriptionCard({required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.primary, AppColors.primaryDark],
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            const Text('💳', style: TextStyle(fontSize: 28)),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Mon abonnement',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16)),
                  Text('Voir mes crédits et renouveler mon offre',
                      style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white),
          ]),
        ),
      );
}
